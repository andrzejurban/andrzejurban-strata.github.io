var app = angular.module('myApp', []);
app.controller('customersCtrl', function ($scope, $http, $interval) {

    $scope.sourcePage = "data.html";
    $scope.data = {};
    var roomsData;
    
    $scope.changeTemperature = function (room, index) {
        room.temperatureToBe = room.temperatureToBe;
        var queryString = "?tempzad" + index + "=" + room.temperatureToBe;
        $http({
            method: "GET",
            url: $scope.sourcePage + queryString,
        });
    };

    $scope.changeTemperaturePod = function () {
        var queryString = "?temppod=" + $scope.settings.tempPod;
        $http({
            method: "GET",
            url: $scope.sourcePage + queryString,
        });
    };

    $scope.check = function (room, index) {
        var newRoomStatus = room.roomStatus;
        var queryString = "?stanpok" + index + "=" + newRoomStatus;
        $http({
            method: "GET",
            url: $scope.sourcePage + queryString,
        });
    };

    $scope.getSettingsFromDataSource = function () {
        $http.get($scope.sourcePage)
            .success(function (data) {
                console.log(data);
                var rawHtml = angular.element(data);
                var rawJson = rawHtml[rawHtml.length - 1].innerHTML; //last element is a json div
                roomsData = JSON.parse(rawJson).rooms;
                if ($scope.data.rooms == undefined) {
                    $scope.data.rooms = roomsData;
                } else {
                    for (var i=0;i<roomsData.length;i++) {
                        $scope.data.rooms[i].temperatureToBe = roomsData[i].temperatureToBe;
                        $scope.data.rooms[i].temperature = roomsData[i].temperature;
                        $scope.data.rooms[i].roomStatus = roomsData[i].roomStatus;
                        
                    }
                }
                $scope.settings = {
                    tempPod: JSON.parse(rawJson).settings.tempPod
                };
            });
    };

    $scope.getSettingsFromDataSource();
    $interval($scope.getSettingsFromDataSource, 5000);

});